import { AbilityBuilder, Ability } from '@casl/ability';

export default function defineAbilitiesFor(role) {
  const { can, cannot, build } = new AbilityBuilder(Ability);

  if (role === 'superAdmin') {
    can('manage', 'all');
  } else if (role === 'admin') {
    can('access', 'admin');
    cannot('access', 'kassa');
  } else if (role === 'kassa') {
    can('access', 'kassa');
    cannot('access', 'admin');
  } else {
    cannot('access', 'admin');
    cannot('access', 'kassa');
  }

  return build();
}
